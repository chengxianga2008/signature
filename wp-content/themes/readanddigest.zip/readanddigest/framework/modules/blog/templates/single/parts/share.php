<div class ="eltdf-blog-single-share">
<h6 class="eltdf-single-share-title"><?php esc_html_e('Share Post', 'readanddigest'); ?></h6>
<?php echo readanddigest_get_social_share_html(array('type'=>'list')); ?>
</div>