<div class="eltdf-post-content-featured">
	<?php readanddigest_get_module_template_part('templates/single/parts/image', 'blog'); ?>
	<?php readanddigest_get_module_template_part('templates/parts/audio', 'blog'); ?>
</div>