<span class="eltdf-post-info-icon-holder">
    <span class="eltdf-post-info-icon <?php echo esc_attr($params['post_type']) ?>"></span>
</span>