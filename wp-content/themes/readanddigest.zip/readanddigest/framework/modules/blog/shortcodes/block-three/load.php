<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/shortcodes/block-three/block-three.php';