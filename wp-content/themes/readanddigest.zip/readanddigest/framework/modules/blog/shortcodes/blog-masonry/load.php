<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/shortcodes/blog-masonry/blog-masonry.php';