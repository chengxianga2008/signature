<div class="eltdf-post-ajax-preloader" style="display: none;">
    <div class="eltdf-pulse"></div>
    <div class="eltdf-pulse"></div>
    <div class="eltdf-pulse"></div>
</div>