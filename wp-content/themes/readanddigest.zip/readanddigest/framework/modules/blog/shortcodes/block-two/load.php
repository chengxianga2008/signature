<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/shortcodes/block-two/block-two.php';