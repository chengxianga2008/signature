<div class="clearfix">
	<div class="eltd_column eltdf-column1">
		<div class="eltdf-column-inner">
			<?php if(is_active_sidebar('footer_column_1')) {
				dynamic_sidebar( 'footer_column_1' );
			} ?>
		</div>
	</div>
</div>