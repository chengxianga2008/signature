<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/post-tabs/post-tabs.php';
