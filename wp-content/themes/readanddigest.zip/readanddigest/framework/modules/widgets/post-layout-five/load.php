<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/post-layout-five/post-layout-five.php';
