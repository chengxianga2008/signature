<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/recent-comments/recent-comments.php';
