<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/breaking-news/breaking-news.php';
