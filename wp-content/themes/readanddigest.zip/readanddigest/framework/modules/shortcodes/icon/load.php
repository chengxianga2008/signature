<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/icon/icon.php';