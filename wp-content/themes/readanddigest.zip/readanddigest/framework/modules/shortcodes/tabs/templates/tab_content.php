<div class="eltdf-tab-container" id="tab-<?php echo sanitize_title( $title )?>">
<?php echo do_shortcode($content); ?>
</div>