<?php
require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tabs.php';
require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tab.php';
