<div class="eltdf-social-share-holder eltdf-list">
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>