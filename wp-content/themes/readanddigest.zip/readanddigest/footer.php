<?php
readanddigest_get_footer();
?>